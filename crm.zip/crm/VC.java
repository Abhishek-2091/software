/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package crm;

class VC
{

 static boolean IsNumeric(String args)
 {
  try
  {
   Integer.parseInt(args);
   return true;
  }
  catch(Exception ex)
  {
   return false;
  }
 }
 
 static boolean IsDouble(String args)
 {
  try
  {
   Double.parseDouble(args);
   return true;
  }
  catch(Exception ex)
  {
   return false;
  }
 }

  static boolean IsName(String args)
    {
        char ch[] = args.toCharArray();
        for (int i = 0; i < ch.length; i++)
        {
            int ascii = ch[i];
            if (!((ascii >= 65 && ascii <= 90) || (ascii >= 97 && ascii <= 122) || ascii == 32))
            {
                return false;
            }
        }
        return true;
    }

}

