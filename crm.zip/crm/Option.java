/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package crm;
import javax.swing.*;

/**
 *
 * @author APT Technosoft
 */
class Option {


//Variable Declaration
String id, value;

//Constructor
Option(String id, String value)
{
 this.id = id;
 this.value = value;
}

public @Override String toString()
{
 return value;
}

public static int getItemIndex(JComboBox ddl,Object obj)
{
	int i=0;
    boolean flag=false;

    for(i=0;i<ddl.getItemCount();i++)
    {
 	   String ItemId=((Option)ddl.getItemAt(i)).id;
 	   if(ItemId.equals(obj))
 	   {
 		   flag=true;
 		   break;
 	   }
    }
 	   if(flag==true)
 		   return i;
 	   else
 		   return -1;

    }

}
