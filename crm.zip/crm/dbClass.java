/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package crm;
import javax.swing.*;
import java.sql.*;
import java.util.*;
import net.sf.jasperreports.view.JasperViewer;
import net.sf.jasperreports.engine.*;

/**
 *
 * @author APT Technosoft
 */
class dbClass {

    private static String jasperPrint;

    dbClass()throws Exception
    {
     Class.forName("com.mysql.jdbc.Driver");
    }

    private Connection dbConnection()throws Exception
{
    Connection conn=DriverManager.getConnection("jdbc:mysql://localhost/ocmsdbase","root","");
    return conn;
}

ResultSet getData(String SQL,boolean Updatable)throws Exception
{
Statement cmd;
if(Updatable==true)
{
 cmd=dbConnection().createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
}
else
{
 cmd=dbConnection().createStatement();
}
ResultSet rs=cmd.executeQuery(SQL);
return rs;
}

ResultSet getData(String SQL,Object arr[])throws Exception
{
 PreparedStatement cmd=dbConnection().prepareStatement(SQL);
 cmd.clearParameters();
 for(int i=1;i<=arr.length;i++)
 {
  cmd.setObject(i,arr[i-1]);
 }
 ResultSet rs=cmd.executeQuery();
 return rs;
}

void ExecuteNonQuery(String SQL)throws Exception
{
 Statement cmd=dbConnection().createStatement();
 cmd.executeUpdate(SQL);
}

void ExecuteParamQuery(String SQL,Object arr[])throws Exception
{
 PreparedStatement cmd=dbConnection().prepareStatement(SQL);
 cmd.clearParameters();
 for(int i=1;i<=arr.length;i++)
 {
  cmd.setObject(i,arr[i-1]);
 }
 cmd.executeUpdate();
}

String GetMaxId(String idField,String TableName,int InitVal,int Diff)throws Exception
{
String tid="";
ResultSet rsMax=this.getData("select max("+ idField +") from "+ TableName +"",false);
if(rsMax.next())
{
tid=rsMax.getString(1);
}
rsMax.close();

int mid=0;

if(tid==null)
{
 mid=InitVal;
}
else
{
 mid=Integer.parseInt(tid) + Diff;
}
return String.valueOf(mid);

}

void FillCombo(JComboBox cmb,String idField,String nmField,String TableName)throws Exception
{
 ResultSet rs=this.getData("Select "+ idField +","+ nmField +" from "+ TableName +"",false);
 cmb.removeAllItems();
 cmb.addItem(new Option("0","Select"));
 while(rs.next())
 {
    cmb.addItem(new Option(rs.getString(1),rs.getString(2)));
 }
 rs.close();
}

void FillCombo(JComboBox cmb,String sql)throws Exception
{
 ResultSet rs=this.getData(sql,false);
 cmb.removeAllItems();
 cmb.addItem(new Option("0","Select"));
 while(rs.next())
 {
    cmb.addItem(new Option(rs.getString(1),rs.getString(2)));
 }
 rs.close();
}


static void RunReport(String ReportPath,String Title)throws Exception
{
     Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/ocmsdbase","root","");  
     JasperPrint jp = JasperFillManager.fillReport(ReportPath,null,cn);
     //JasperViewer jviewer=new JasperViewer(jp,false);
     JasperViewer jviewer = new JasperViewer(jasperPrint, false);
     JDialog frm=new JDialog((JFrame)null,Title,true);
    frm.getContentPane().add(jviewer.getContentPane());
     frm.setSize(jviewer.getSize());
     frm.setLocationRelativeTo(null);     
     frm.setVisible(true);
}

static void RunReport(String ReportPath,String Title,HashMap<String,Object> map)throws Exception
{
 Connection cn=DriverManager.getConnection("jdbc:mysql://localhost/ocmsdbase","root","");
  JasperPrint jp = JasperFillManager.fillReport(ReportPath,map,cn);
     JasperViewer jviewer=new JasperViewer(jasperPrint,false);
    JDialog frm=new JDialog((JFrame)null,Title,true);
    frm.getContentPane().add(jviewer.getContentPane());
    frm.setSize(jviewer.getSize());
    frm.setLocationRelativeTo(null);     
    frm.setVisible(true);
}



}
